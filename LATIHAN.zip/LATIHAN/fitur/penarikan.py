import streamlit as st

st.title("Halaman Penarikan")
st.image("https://www.pngmart.com/files/16/Finance-Banking-PNG-HD.png", caption="ini gambar bank")