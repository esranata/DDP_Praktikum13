import streamlit as st

st.title("Halaman Dashboard")

# Fungsi Untuk Menghitung dan Menyimpan Total Tabungan
def total():
    total_nabung = sum(t['Jumlah'] for t in st.session_state['Jumlah'] if t['Tipe'] == 'Menabung')

    return f"Total Tabungan Anda {total_nabung}"

st.write(total())