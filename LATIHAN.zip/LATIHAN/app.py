import streamlit as st

# Side Bar Direktory
dashboard = st.Page("./fitur/dashboard.py", title ="Dashboard")
nabung = st.Page("./fitur/Nabung.py", title="Nabung")
penarikan = st.Page("./fitur/penarikan.py", title="pernarikan")

pg = st.navigation({
        "Menu Utama":[dashboard],
        "Transaksi":[nabung],
        "Penatikan": [penarikan]
    }
)

if 'Jumlah' not in st.session_state:
    st.session_state['Jumlah'] = []
   

# Menjalankan nafigasi
pg.run()



if 'jumlah' not in st.session_state:
    st.session_state['jumlah'] = []

# Fungsi Untuk Menghitung Dan Menyimpan Total Nabung
def total(jumlah):
    total_nabung = sum(t[jumlah] for t in jumlah if t['Tipe'] == 'Menabung')

    return total_nabung


